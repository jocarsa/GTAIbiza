const tamanyoCanvas = 1000;
const frameTime     = 16.66667;

// Cargamos el lienzo donde vamos a dibujar
var lienzo = document.getElementById("lienzo1");
var contexto = lienzo.getContext("2d");

// Cargamos la imagen del coche
var imagenPez = new Image();
imagenPez.src = "img/coche.png";

// Creamos un temporizador
var temporizador;

// Creo los peces
var nPeces = 3000;
var peces = new Array();

// Cambio de direccion aleatorio
var cambioDireccion	= 3000;
var tiempoDireccion = cambioDireccion;
var ratioDireccion	= 0.5;

// Cambio de sentido aleatorio
var cambioSentido	= 35000;
var tiempoSentido   = cambioSentido;
var sentido         = true;


// Cambio de radio aleatorio
var cambioRadio	= 8445;
var tiempoRadio = cambioRadio;	
var ratioRadio	= 60;

// Cambio de centro aleatorio
var cambioCentro = 14000;
var tiempoCentro = cambioRadio;	
var ratioCentro	 = 50;


// Creo el cursor
var cursor;	

// Ejecutamos la funcion de inicio
inicio();