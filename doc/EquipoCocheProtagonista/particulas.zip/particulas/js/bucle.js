function bucle(){
	//contexto.clearRect(0,0,tamanyoCanvas,tamanyoCanvas);
	contexto.fillStyle = "black";
	contexto.fillRect(0,0,tamanyoCanvas,tamanyoCanvas,);
	
	// Dibujo 
	for (var i = 0; i < nPeces; i++) {
		// Dibujar
		//peces[i].dibujaPez("blue");
		
		//peces[i].dibujaCabeza();
		//peces[i].dibujaCuerpo();
		//peces[i].dibujaArticulaciones();
		//peces[i].dibujaCentro();
		//peces[i].dibujaObjetivo();
		//peces[i].dibujaPez("white");
		peces[i].dibujaPez2("white");
		//peces[i].dibujaVelocidad();
		
		// Mover
		peces[i].mueveObjetivo();
		peces[i].ondula();
		peces[i].nada();
		peces[i].persigueObjetivo();
		peces[i].cambiaDireccion();
		peces[i].cambiaRadio();
		//peces[i].cambiaSentido();

		//peces[i].colisionparedes();
	}
	//cambiaDireccion();
	cambiaRadio();
	cambiaSentido();
	cambiaCentro();

	
	clearTimeout(temporizador);
	temporizador = setTimeout("bucle()",frameTime);
}
