function inicio(){
	
	contexto.fillStyle = "black";
	contexto.strokeStyle = "black";

	cursor = new Cursor();

	for (var i = 0; i < nPeces; i++) {
		peces[i] = new Pez();
		// Propiedades			
		peces[i].constructor();

	}

	// Código JQuery
	$("canvas").mousemove(function(event){
		// Al hacer doble click expulso a los peces		
		//mueveCentro(event.pageX,event.pageY);
		//for (var i = 0; i < nPeces; i++){		
			//peces[i].huye(event.pageX,event.pageY);		
			//peces[i].persigue(event.pageX,event.pageY);					
		//}
		// Muestro el cursor
		cursor.dibuja(event.pageX, event.pageY, 20);
	})

	$("canvas").click(function(event){
		// Al hacer click cambio el centro
		mueveCentro(event.pageX,event.pageY);
		//for (var i = 0; i < nPeces; i++){		
			
		//}		
	})
	
	temporizador = setTimeout("bucle()", 2000);





}
