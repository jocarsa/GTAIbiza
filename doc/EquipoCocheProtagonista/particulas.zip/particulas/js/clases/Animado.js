Animado.prototype = new Actor(); // Animado hereda de actor
function Animado(){
	// Propiedades	
		this.rotX		= 0;	// Rotación en el eje x
		this.rotY		= 0;	// Rotación en el eje y
		this.rotZ		= 0;	// Rotación en el eje z
		this.velocidad	= 1;	// Velocidad
}

