Articulacion.prototype = new Actor(); // Vehiculo hereda de actor
function Articulacion(){
	// Propiedades	
		
	// Métodos


}

