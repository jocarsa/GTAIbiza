function Actor(){
	// Propiedades
		this.posX = 0; // Posición en el eje x
		this.posY = 0; // Posición en el eje y
		this.posz = 0; // Posición en el eje z 
	// Métodos

}