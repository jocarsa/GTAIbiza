Pez.prototype = new Animado(); // Pez hereda de animado
function Pez(){
	// Propiedades	//

	// Heredadas
	this.posX		= 0;//this.bordeColision + (Math.random() * tamanyoCanvas);
	this.posY		= 0;//this.bordeColision + (Math.random() * tamanyoCanvas);
	this.rotZ		= 2 * Math.PI * (1/8); //2 * Math.PI * Math.random();//2 * Math.PI * (1/8);
	this.velocidad	= 1;

	// Clase Pez	
	this.posXOndula = this.posX;
	this.posYOndula = this.posY;
	this.velocidadInicial	= 1;
	this.bordeColision		= 10; 
	
	// Cambio de direccion aleatorio
	this.cambioDireccion	= 1000;
	this.tiempoDireccion    = this.cambioDireccion;	
	this.ratioDireccion		= 0;

	// Cambio de sentido aleatorio
	this.cambioSentido		= 10000;
	this.tiempoSentido    	= this.cambioSentido;

	// Cambio de radio aleatorio
	this.cambioRadio	= 1000 * Math.random();
	this.tiempoRadio    = this.cambioRadio;	
	this.ratioRadio		= 30;
	
	// Parámetros para huir y perseguir
	this.temeridad          = 30;
	this.avistamiento       = 500;

	// Objetivo a sequir que gira dando vueltas a su centro	
	this.objetivo = new Objetivo();			// Instancia objetivo
	this.objetivo.posX = 0;				// Coordenada x del objetivo
	this.objetivo.posY = 0;				// Coordenada y del objetivo
	this.objetivo.centroRadio = 20 + (Math.random() * 100);					// Distancia al centro del objetivo
	this.objetivo.velocidadAngular = 45/this.objetivo.centroRadio;	// Velocidad angular rad/s
	this.objetivo.angulo		 = Math.random() * 2 * Math.PI;					// Angulo inicial del giro del objetivo	
	this.objetivo.centro.posX = tamanyoCanvas/2 + 0;
	this.objetivo.centro.posY = tamanyoCanvas/2 + 0;
	
	//  Movimiento ondulatorio 
	this.amplitud = 1.1;		// Ampliud de onda
	this.periodo  = 0.4; 	// Número de segundos que tarda en repetirse
	this.fase     = 2 * Math.PI * Math.random(); 		// Angulo inicial de la onda. En 0 empieza en el centro

	// Cuerpo articulado
	this.nArticulaciones			= 10;
	this.nArticulacionesVisibles	= 10;
	this.articulaciones				= new Array();
	
	// Variables privadas
	this.tiempo = 0;
	this.dirOndula;
		
	// Métodos	//
	this.constructor = function(){
		
		this.velocidad	= this.velocidadInicial;
		this.tiempoDireccion = this.cambioDireccion;
		this.posXOndula = this.posX;
		this.posYOndula = this.posY;
		this.posX = 1 + this.bordeColision + (Math.random() * (tamanyoCanvas - (2 * this.bordeColision) - 2));
		this.posY = 1 + this.bordeColision + (Math.random() * (tamanyoCanvas - (2 * this.bordeColision) - 2));
		
		this.posX = -100 + Math.random() * -800;
		this.posY = -100 + Math.random() * -800;


		for (var i = 0; i< this.nArticulaciones ; i++){
			this.articulaciones[i] = new Articulacion();
			this.articulaciones[i].posX = this.posX;
			this.articulaciones[i].posY = this.posY;
		}		
	}

	// Dibuja pez
	this.dibujaPez = function(aColor){		
		// Dibuja la cabeza		
		dibujaRectangulo(this.articulaciones[0].posX,
					this.articulaciones[0].posY,
					1,1,"cyan","F");
		dibujaRectangulo(this.articulaciones[1].posX,
					this.articulaciones[1].posY,
					1.3,1.3,"cyan","F");
		dibujaRectangulo(this.articulaciones[2].posX,
					this.articulaciones[2].posY,
					1.5,1,5,"red","F");
		dibujaRectangulo(this.articulaciones[3].posX,
					this.articulaciones[3].posY,
					1.2,1.2,"red","F");
		dibujaRectangulo(this.articulaciones[4].posX,
					this.articulaciones[4].posY,
					0.8,0.8,"red","F");
		dibujaRectangulo(this.articulaciones[5].posX,
					this.articulaciones[5].posY,
					1,1,"white","F");
	}

		// Dibuja pez
	this.dibujaPez2 = function(aColor){		
		// Dibuja la cabeza		
		dibujaRectangulo(this.articulaciones[0].posX,
					this.articulaciones[0].posY,
					0.5,0.5,aColor,"F");
		dibujaRectangulo(this.articulaciones[1].posX,
					this.articulaciones[1].posY,
					1,1,aColor,"F");
		dibujaRectangulo(this.articulaciones[2].posX,
					this.articulaciones[2].posY,
					1.5,1.5,aColor,"F");
		dibujaRectangulo(this.articulaciones[3].posX,
					this.articulaciones[3].posY,
					1.6,1.6,aColor,"F");
		dibujaRectangulo(this.articulaciones[4].posX,
					this.articulaciones[4].posY,
					1.5,1.5,aColor,"F");
		dibujaRectangulo(this.articulaciones[5].posX,
					this.articulaciones[5].posY,
					1.3,1.3,aColor,"F");
		dibujaRectangulo(this.articulaciones[6].posX,
					this.articulaciones[6].posY,
					1.2,1.2,aColor,"F");
		dibujaRectangulo(this.articulaciones[7].posX,
					this.articulaciones[7].posY,
					1.1,1.1,aColor,"F");
		dibujaRectangulo(this.articulaciones[8].posX,
					this.articulaciones[8].posY,
					1,1,aColor,"F");
		dibujaRectangulo(this.articulaciones[9].posX,
					this.articulaciones[9].posY,
					1,1,aColor,"F");
	}

	
	// Dibuja la cabeza
	this.dibujaCabeza = function(){		
		// Dibuja la cabeza		
		dibujaRectangulo(this.posXOndula, this.posYOndula, 2, 2, "blue", "F");		
	}
	
	// Dibuja el cuerpo en movimiento ondulatorio
	this.dibujaCuerpo = function(){		
		// Variables locales
		var ultimoIndice	= 0;
		var hueco			= 0;
				
		for (var i=0; i < this.nArticulaciones - 1; i++) {
			if (hueco <= 0){
				contexto.S
				dibujaLinea(this.articulaciones[i].posX,
							this.articulaciones[i].posY,
							this.articulaciones[ultimoIndice].posX,
							this.articulaciones[ultimoIndice].posY,
							"blue");
				ultimoIndice = i;
				hueco = this.nArticulaciones/this.nArticulacionesVisibles;
			}
			hueco--;			
		}
	}
	
	// Dibuja las articulaciones en movimiento ondulatorio
	this.dibujaArticulaciones = function(){		
		// Variables locales
		var ultimoIndice	= 0;
		var hueco			= 0;		
		
		for (var i=0; i < this.nArticulaciones - 1; i++) {
			if (hueco <= 0){
				dibujaRectangulo(this.articulaciones[i].posX, this.articulaciones[i].posY, 1, 1, "white", "F");
				ultimoIndice = i;
				hueco = this.nArticulaciones/this.nArticulacionesVisibles;
			}
			hueco--;			
		}
	}


	// Dibuja el punto de referencia del objeto
	this.dibujaCentro = function(){
		dibujaRectangulo(this.posX, this.posY, 4, 4, "red", "F");
	}

	// Dibuja el el vector velocidad
	this.dibujaVelocidad = function(){
		
		dibujaLinea(this.posX,
					this.posY,
					this.posX + (Math.cos(this.rotZ) * this.velocidad * 10),
					this.posY + (Math.sin(this.rotZ) * this.velocidad * 10),
					"red");
	}

		
	// Dibuja el objetivo que sigue el pez
	this.dibujaObjetivo = function(){				
		dibujaRectangulo(this.objetivo.posX, this.objetivo.posY, 1, 1 ,"red","F");
	}

	// Rebota en los límites del canvas con un borde
	this.colisionparedes = function(){
		if(this.posX > tamanyoCanvas - this.bordeColision)	{this.posX = tamanyoCanvas - this.bordeColision	; this.rotZ = - (this.rotZ + Math.PI);}
		if(this.posX < this.bordeColision)                	{this.posX = this.bordeColision                	; this.rotZ = - (this.rotZ + Math.PI);}
		if(this.posY > tamanyoCanvas - this.bordeColision)	{this.posY = tamanyoCanvas - this.bordeColision	; this.rotZ = - (this.rotZ);}
		if(this.posY < this.bordeColision)					{this.posY = this.bordeColision    				; this.rotZ = - (this.rotZ);}
	}

	// Cambia la dirección y aumenta la velocidad cuando se acerca el cursor del ratón
	this.huye = function(x, y){
		
		var catX = x - this.posX;
		var catY = y - this.posY;
		var distancia = Math.sqrt(Math.pow(catX, 2) + Math.pow(catY, 2));
		
		if (distancia < this.temeridad) {
			this.rotZ = Math.asin(catY/distancia);								
			if (catX < 0) {
				this.rotZ = -this.rotZ;
			} else {
				this.rotZ += Math.PI
			}
			this.velocidad += 0.1;
			this.huyendo = true;
		} else{
			this.huyendo = false;
		}
	}

	this.mueveObjetivo = function(){
		// Mueve el objetivo circularmente
		this.objetivo.mover();		
	}
	
	// Persigue al objetivo
	this.persigueObjetivo = function(){		
		this.persigue(this.objetivo.posX, this.objetivo.posY);	
	}

	// Persigue un punto
	this.persigue = function(x,y){
		var catX = x - this.posX;
		var catY = y - this.posY;
		var distancia = Math.sqrt(Math.pow(catX, 2) + Math.pow(catY, 2));
		
		if (distancia < 10) {
			this.velocidad -= 0.1;
		} else {
			this.velocidad = this.velocidadInicial;
		}
	
		this.rotZ = anguloEntrePuntos(this.posX,this.posY,x,y);

	}
	
	// Sigue una dirección principal y controla la velocidad
	this.nada = function(){

		// Reajusta la velocidad si se ha incrementado por encima de la velocidad inicial
		if (this.velocidad > this.velocidadInicial){
			this.velocidad -= 0.02;
		}
		
		/*
		if (this.velocidad < 0.2){
			this.velocidad += 0.02;
		}

		
		this.velocidadInicial = (Math.random() - 0.5) * 0.03;
		this.velocidad += (Math.random() - 0.5) * 0.03;
		*/
		// Calcula la posición 
		this.posX += Math.cos(this.rotZ) * this.velocidad;	// Actualizo posición x del pez
		this.posY += Math.sin(this.rotZ) * this.velocidad;	// Actualizo posición y del pez
	}
	
	// Hace el movimiento ondulatorio y maneja el vector de articulaciones	
	this.ondulaOld = function(){		
		// Función obsoleta
		// Estas variables serían propiedades si se usaran
		var movSinuoso			= 0.5; 
		var movTamanyo			= 0.1;	
		// Estas variables serían propiedades si se usaran
		
		// Se calcula el desfase para el movimiento ondulatorio con una función de onda en el tiempo
		this.tiempo += (frameTime/1000) * (this.velocidadInicial / this.movTamanyo);
		this.dirOndula = this.movSinuoso * Math.sin(this.tiempo);
		// Posiciones x e y con el movimiento ondulatorio this.dirOndula sumado al principal (this.rotZ)
		this.posXOndula += Math.cos(this.rotZ + this.dirOndula) * this.velocidad;	// Actualizo posición x del bot
		this.posYOndula += Math.sin(this.rotZ + this.dirOndula) * this.velocidad;	// Actualizo posición y del bot

		// Se elimina la última posición
		this.articulaciones.pop();		
		// Se crea una nueva posición con las nuevas coordenadas calculadas
		this.articulaciones.unshift(new Articulacion);
		this.articulaciones[0].posX = this.posXOndula;
		this.articulaciones[0].posY = this.posYOndula;		
	}	

	// Hace el movimiento ondulatorio y maneja el vector de articulaciones	
	this.ondula = function(){		
		// Variables locales
		var desfase;
		var desfaseX;
		var desfaseY;
	
		// Se calcula el desfase con la función de onda del movimiento armónico simple
		this.tiempo += (frameTime/1000);		
		desfase = this.amplitud *  Math.sin(((2 * Math.PI/this.periodo) * this.tiempo) + this.fase);
		// Se rota el desfase en la dirección perpendicular al movimiento principal
		desfaseX = Math.cos(this.rotZ + (Math.PI/2)) * desfase;
		desfaseY = Math.sin(this.rotZ + (Math.PI/2)) * desfase;
		
		this.posXOndula = this.posX + desfaseX;	// Actualizo posición x del bot
		this.posYOndula = this.posY + desfaseY;	// Actualizo posición y del bot
		
		// Se elimina la última posición
		this.articulaciones.pop();		
		// Se crea una nueva posición con las nuevas coordenadas calculadas
		this.articulaciones.unshift(new Articulacion);
		this.articulaciones[0].posX = this.posXOndula;
		this.articulaciones[0].posY = this.posYOndula;
		
	}	
	
	// Cambia de radio cada tiempo indicado
	this.cambiaRadio = function(){				
		this.tiempoRadio -= frameTime;
		if (this.tiempoRadio < 0) {
			this.tiempoRadio = this.cambioRadio;
			// Varia ligeramente el radio de forma aleatoria
			this.objetivo.centroRadio += this.ratioRadio * (Math.random() - 0.5);
			if (Math.abs(this.objetivo.centroRadio) < (this.ratioRadio/2)){this.objetivo.centroRadio = (this.ratioRadio/2)};
		}
	}

	// Cambia de dirección cada tiempo marcado por this.cambioDireccion en milisegundos
	this.cambiaDireccion = function(){				
		this.tiempoDireccion -= frameTime;
		if (this.tiempoDireccion < 0) {
			this.tiempoDireccion = this.cambioDireccion;
			this.rotZ += (Math.random() - 0.5) * this.ratioDireccion;
		}
	}


	// Cambia de sentido cada tiempo marcado por this.cambioSentido en milisegundos
	this.cambiaSentido = function(){				
		this.tiempoSentido -= frameTime;
		if (this.tiempoSentido < 0) {
			this.tiempoSentido = this.cambioSentido * Math.random();
			this.objetivo.velocidadAngular = -this.objetivo.velocidadAngular;			
		}
	}

}













